from Crypto.Util import number
import random


def generate_prime():
    length = 16
    prime_num = number.getPrime(length)
    return prime_num


def factorization(num, factor_list=[]):
    for i in range(2, num // 2 + 1):
        if num % i == 0:
            if i not in factor_list:
                factor_list.append(i)
            factorization(num // i, factor_list)
            return factor_list
        if i >= (num // 2 - 1):
            factor_list.append(num)
            break


def get_element(prime):
    q = prime - 1
    f_list = factorization(q)
    for i in range(10, q):
        for j in f_list:
            flag = 1
            if (i ** (q // j)) % prime == 1:
                flag = 0
                continue
        if flag == 1:
            return i


def exchange(client):
    # 随机生成大素数
    prime = generate_prime()
    # 获得大素数的一个生成元
    generator = get_element(prime)
    data = [prime, generator].__str__().encode()
    client.send(data)
    # 接收g^b mod p
    receive_b = client.recv(1024)
    # 生成随机数a
    number_a = random.randint(1, prime - 2)
    send_a = generator ** number_a % prime
    client.send(str(send_a).encode())
    number_b = int(receive_b.decode())
    # 计算得到协商密钥
    number_key = number_b ** number_a % prime
    return number_key


def key_config(key, client):
    while True:
        recv_key = int(client.recv(128).decode())
        if key != recv_key:
            key = exchange(clint)
        else:
            return key

# ghost_clint = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# ghost_clint.connect(("192.168.43.90", 6000))
# key = exchange(ghost_clint)
# key = key_config(key, ghost_clint)
# print(key)
