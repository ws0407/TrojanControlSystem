from Crypto.Cipher import AES
import os
import psutil
import time


def get_path(disk):
    res = {'dirname': disk, 'child_dirs': [], 'files': []}
    return list_dir(disk, res)


def list_dir(path, res):
    if path == 'root\\':
        res['child_dirs'] = disk_information()
    else:
        try:
            path = path[6:]
            dirs = os.listdir(path)
            print(path)
            for i in dirs:
                temp_dir = os.path.join(path, i)
                if os.path.isdir(temp_dir):
                    length = len(path)
                    if path[-1] == ":" or path[-2] == ":":
                        res['child_dirs'].append(temp_dir[length:])
                    else:
                        res['child_dirs'].append(temp_dir[length + 1:])
                else:
                    res['files'].append(i)
        except PermissionError:
            i = 1
        except FileNotFoundError:
            i = 1
    return res


def file_download(path):
    print(path)
    client_file_send = open(path, 'rb')
    data = client_file_send.read()
    client_file_send.close()
    return data


def file_upload(client):
    client_file_recv_path = client.recv(256)
    total_data = b''
    flag = 1
    while flag:
        client_file_data = client.recv(1024)
        if client_file_data == b'end\x00':
            flag = 0
            break
        total_data += client_file_data
    f = open(client_file_recv_path.decode('UTF-8', 'ignore').strip().strip(b'\x00'.decode()), "wb")
    f.write(total_data)
    f.close()


# 利用比特流进行文件加密
def file_encrypt(path):
    file = open(path, "rb+")
    data = file.read()
    sessionkey = '1qazxsw211112222'
    cipherAes = AES.new(sessionkey.encode(), AES.MODE_CBC)
    ciphertext = cipherAes.encrypt(aes_pad(data))
    file.close()
    os.remove(path)
    new_file = open(path, 'wb')
    new_file.write(ciphertext)
    new_file.close()


# aes加解密填充
def aes_pad(s):
    x = AES.block_size - len(s) % AES.block_size
    return s + ((bytes([x])) * x)


# 利用比特流进行文件解密
def file_decrypt(path):
    file = open(path, "rb+")
    data = file.read()
    sessionkey = '1qazxsw211112222'
    cipherAes = AES.new(sessionkey.encode(), AES.MODE_CBC)
    decryptedtext = cipherAes.decrypt(data)[AES.block_size:]
    file.close()
    os.remove(path)
    new_file = open(path, 'wb')
    new_file.write(decryptedtext)
    new_file.close()


# 获取磁盘信息
def disk_information():
    temp = psutil.disk_partitions()
    disk_list = []
    for i in range(len(temp)):
        disk_list.append(temp[i][0])
    return disk_list


def file_information(path):
    stateinfo = os.stat(path)
    last_modification = time.localtime(stateinfo.st_mtime)
    last_modification_time = time.strftime("%Y-%m-%d %H:%M:%S", last_modification)
    f_info = {'file_size': stateinfo.st_size, 'last_modification_time': last_modification_time}
    return f_info

