import win32con
import win32api


def my_message(message):
    win32api.MessageBox(0, message, "warning", win32con.MB_OK)


