import time

import win32gui
import win32print
import win32ui
import win32con
import win32api
import os

from PIL import Image


def screenshotter(socket):
    # 获取桌面窗口句柄
    hdesktop = win32gui.GetDesktopWindow()

    # 获取所有显示屏的像素尺寸
    hDC = win32gui.GetDC(0)
    width = win32print.GetDeviceCaps(hDC, win32con.DESKTOPHORZRES)
    height = win32print.GetDeviceCaps(hDC, win32con.DESKTOPVERTRES)
    left = win32api.GetSystemMetrics(win32con.SM_XVIRTUALSCREEN)
    top = win32api.GetSystemMetrics(win32con.SM_YVIRTUALSCREEN)
    print(width,height,left,top)

    # 创建设备描述表
    desktop_dc = win32gui.GetWindowDC(hdesktop)
    img_dc = win32ui.CreateDCFromHandle(desktop_dc)

    # 创建基于内存的设备描述表
    mem_dc = img_dc.CreateCompatibleDC()

    # 创建位图对象
    screenshot = win32ui.CreateBitmap()
    screenshot.CreateCompatibleBitmap(img_dc, width, height)
    mem_dc.SelectObject(screenshot)

    # 复制屏幕到我们的内存设备描述表中
    mem_dc.BitBlt((0, 0), (width, height), img_dc, (left, top), win32con.SRCCOPY)
    #文件保存到本地
    screenshot.SaveBitmapFile(mem_dc, 'D:\\screenshot.bmp')

    #压缩图片
    sImg = Image.open('D:\\screenshot.bmp')
    w,h = sImg.size
    dImg = sImg.resize((int(w/2), int(h/2)), Image.ANTIALIAS)
    dImg.save('D:\\screenshot.bmp')

    with open("D:\\screenshot.bmp", "rb") as screenshotFile:
        base64_data = screenshotFile.read()

    socket.sendall(base64_data)
    #print("data sent!")
    time.sleep(2)
    socket.send("end".encode())
    #print("end sent!")

    os.remove("D:\\screenshot.bmp")

    mem_dc.DeleteDC()
    win32gui.DeleteObject(screenshot.GetHandle())


