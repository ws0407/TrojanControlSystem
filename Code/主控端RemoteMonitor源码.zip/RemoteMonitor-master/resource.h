﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 RemoteMonitor.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REMOTEMONITOR_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDD_DIALOG_FILE                 131
#define IDR_MENU2                       133
#define IDD_DIALOG_HOST_DETAIL          134
#define IDR_MENU_FOLDER                 136
#define IDR_MENU4                       137
#define IDR_MENU_FILE                   137
#define IDB_BITMAP1                     138
#define IDR_JPG1                        140
#define IDD_DIALOG_KEYBOARD_SPY         141
#define IDD_DIALOG_CONNECT              144
#define IDD_DIALOG_SHELL                146
#define IDI_ICON1                       155
#define IDI_ICON_WRONG                  160
#define IDI_ICON_YES                    161
#define IDI_ICON_FOLDER                 162
#define IDI_ICON_FILE                   163
#define IDI_ICON_MUSIC                  164
#define IDI_ICON_PIC                    165
#define IDI_ICON_ZIP                    166
#define IDD_DIALOG1                     167
#define IDI_ICON_ICON                   169
#define IDI_ICON_RADAR                  169
#define IDC_HOST_LIST                   1000
#define IDC_BUTTON1                     1001
#define IDC_BUTTON_STOP                 1001
#define IDC_EDIT_FILE                   1002
#define IDC_LIST_FILE                   1004
#define IDC_BUTTON_TURNTO               1005
#define IDC_BUTTON3                     1007
#define IDC_BUTTON_SELECT_FILE          1007
#define IDC_BUTTON4                     1008
#define IDC_BUTTON_UPLOAD_FILE          1008
#define IDC_HOST_DETAIL                 1009
#define IDC_BUTTON_HOST_DETAIL          1009
#define IDC_BUTTON_RETURN               1010
#define IDC_BUTTON2                     1011
#define IDC_BUTTON_DISCONNECT           1011
#define IDC_STATIC_PORT                 1012
#define IDC_BUTTON_FILE_RETURN          1012
#define IDC_STATIC_IP                   1013
#define IDC_LIST_KEYBOARD_CONTROL       1013
#define IDC_STATIC_HOST_INFOMATION      1013
#define IDC_STATIC_CAPTION              1014
#define IDC_STATIC_FILE_SELECT          1014
#define IDC_STATIC_IP_DISPLAY           1015
#define IDC_STATIC_HOME_CAPTION         1015
#define IDC_STATIC_PORT_DISPLAY         1016
#define IDC_STATIC_CONNECT_TEXT         1016
#define IDC_STATIC_CONNECT_STATUS_DISPLAY 1017
#define IDC_EDIT_SHELL                  1017
#define IDC_STATIC_CONNECT_STATUS       1018
#define IDC_EDIT_MESSAGE                1018
#define IDC_BUTTON_SCREEN_SHOT          1019
#define IDC_BUTTON_SCREEN_RECORDING     1020
#define IDC_BUTTON_KEYBOARD_SPY         1021
#define IDC_STATIC_PICTURE              1022
#define ID_SYSTEM                       32771
#define ID_SYSTEM_SETTING               32772
#define ID_CTREATE_CONNECTION           32773
#define ID_LINK_32774                   32774
#define ID_LINK_32775                   32775
#define ID_LINK_32776                   32776
#define ID_LINK_32777                   32777
#define ID_LINK_32778                   32778
#define ID_LINK_32779                   32779
#define ID_LINK_32780                   32780
#define ID_LINK_32781                   32781
#define ID_LINK_32782                   32782
#define ID_LINK_OPEN_FOLDER             32783
#define ID_LINK_DETELE_ALL              32784
#define ID_LINK_32785                   32785
#define ID_LINK_DOWNLOAD                32786
#define ID_LINK_DELETE                  32787
#define ID_LINK_ENCODING                32788
#define ID_LINK_DECODING                32789
#define ID_LINK_DETAIL                  32790
#define ID_LINK_32791                   32791
#define ID_LINK_                        32792
#define ID_LINK_HOST_DETAIL             32793
#define ID_LINK_FILEMGR                 32794
#define ID_CONNECT                      32795
#define ID_LINK_DISCONNECT              32796
#define ID_LINK_32797                   32797
#define ID_LINK_CONNECT                 32798
#define ID_LINK_32799                   32799
#define ID_LINK_TERMINAL                32800
#define ID_LINK_32801                   32801
#define ID_LINK_DELETE_HOST             32802
#define ID_LINK_32803                   32803
#define ID_LINK_MESSAGEBOX              32804

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        170
#define _APS_NEXT_COMMAND_VALUE         32805
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
